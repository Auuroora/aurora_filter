/*****************************************************************************
*								HSV.cpp
*
*	���: 
		����, ��Ȳ, ���, �ʷ�, �Ķ�, ������� ����, ä��, ��⸦ ����
*	
*	���� ����: 
*		1. Input BGR Image
*		2. HSV convert
*		3. change Hue, Saturation, Value in range
*		4. save mask
*		5. BGR convert
*	
*****************************************************************************/
#include "define.h"
#include "header.h"

using namespace cv;
using namespace std;

void regHue(int color, int cnt) {
	int from, to;

	switch (color) {
		case RED:	 
			tie(from, to) = make_pair(HUE_RED_LB, HUE_RED_UB);
			swap(beR, afR);
			afR = cnt;
			cnt = (afR - beR);
			break;
		case ORANGE: 
			tie(from, to) = make_pair(HUE_ORANGE_LB, HUE_ORANGE_UB);	
			swap(beO, afO);
			afO = cnt;
			cnt = (afO - beO);
			break;
		case YELLOW: 
			tie(from, to) = make_pair(HUE_YELLOW_LB, HUE_YELLOW_UB);	
			swap(beY, afY);
			afY = cnt;
			cnt = (afY - beY);
			break;
		case GREEN:  
			tie(from, to) = make_pair(HUE_GREEN_LB, HUE_GREEN_UB);
			swap(beG, afG);
			afG = cnt;
			cnt = (afG - beG);
			break;
		case BLUE:	 
			tie(from, to) = make_pair(HUE_BLUE_LB, HUE_BLUE_UB);	
			swap(beB, afB);

			afB = cnt;
			cnt = (afB - beB);
			break;
		case VIOLET: 
			tie(from, to) = make_pair(HUE_VIOLET_LB, HUE_VIOLET_UB);	
			swap(beV, afV);
			afV = cnt;
			cnt = (afV - beV);
			break;
	}

	for (int y = 0; y < originImg.size().height; y++) {

		uchar* ptrHueOrigin = originSplit[0].ptr<uchar>(y);
		ushort* ptrHueDiff = hueDiff.ptr<ushort>(y);

		for (int x = 0; x < originImg.size().width; x++) {
			if ((color == RED) && (RANGE_RED(ptrHueOrigin[x]))) {
				ptrHueDiff[x] += cnt;
			}
			else if (from <= ptrHueOrigin[x] && ptrHueOrigin[x] <= to) {
				ptrHueDiff[x] += cnt;
			}
		}

	}

	for (int y = 0; y < originImg.size().height; y++) {

		uchar* ptrHueOrigin = originSplit[0].ptr<uchar>(y);
		uchar* ptrHueFilter = filterSplit[0].ptr<uchar>(y);
		ushort* ptrHueDiff = hueDiff.ptr<ushort>(y);
		
		for (int x = 0; x < originImg.size().width; x++) {
			if (ptrHueOrigin[x] + ptrHueDiff[x] < 0)
				ptrHueFilter[x] = (ptrHueOrigin[x] + ptrHueDiff[x] + HUE_MAX + 1);
			else
				ptrHueFilter[x] = (ptrHueOrigin[x] + ptrHueDiff[x]) % (HUE_MAX + 1);
		}

	}
}

void regSat(int color, int cnt) {
	int from, to;

	switch (color) {
	case RED:
		tie(from, to) = make_pair(HUE_RED_LB, HUE_RED_UB);
		swap(beR, afR);
		afR = cnt;
		cnt = (afR - beR);
		break;
	case ORANGE:
		tie(from, to) = make_pair(HUE_ORANGE_LB, HUE_ORANGE_UB);
		swap(beO, afO);
		afO = cnt;
		cnt = (afO - beO);
		break;
	case YELLOW:
		tie(from, to) = make_pair(HUE_YELLOW_LB, HUE_YELLOW_UB);
		swap(beY, afY);
		afY = cnt;
		cnt = (afY - beY);
		break;
	case GREEN:
		tie(from, to) = make_pair(HUE_GREEN_LB, HUE_GREEN_UB);
		swap(beG, afG);
		afG = cnt;
		cnt = (afG - beG);
		break;
	case BLUE:
		tie(from, to) = make_pair(HUE_BLUE_LB, HUE_BLUE_UB);
		swap(beB, afB);
		afB = cnt;
		cnt = (afB - beB);
		break;
	case VIOLET:
		tie(from, to) = make_pair(HUE_VIOLET_LB, HUE_VIOLET_UB);
		swap(beV, afV);
		afV = cnt;
		cnt = (afV - beV);
		break;
	}
	
	for (int y = 0; y < originImg.size().height; y++) {

		uchar* ptrHueOrigin = originSplit[0].ptr<uchar>(y);
		ushort* ptrSatDiff = satDiff.ptr<ushort>(y);

		for (int x = 0; x < originImg.size().width; x++) {
			if ((color == RED) && (RANGE_RED(ptrHueOrigin[x]))) {
				ptrSatDiff[x] += cnt;
			}
			else if (from <= ptrHueOrigin[x] && ptrHueOrigin[x] <= to) {
				ptrSatDiff[x] += cnt;
			}
		}

	}
	

	for (int y = 0; y < originImg.size().height; y++) {

		uchar* ptrSatOrigin = originSplit[1].ptr<uchar>(y);
		uchar* ptrSatFilter = filterSplit[1].ptr<uchar>(y);
		ushort* ptrSatDiff = satDiff.ptr<ushort>(y);
		
		for (int x = 0; x < originImg.size().width; x++) {
			if (ptrSatOrigin[x] + ptrSatDiff[x] > SAT_MAX)
				ptrSatFilter[x] = SAT_MAX;
			else if (ptrSatOrigin[x] + ptrSatDiff[x] < SAT_MIN)
				ptrSatFilter[x] = SAT_MIN;
			else
				ptrSatFilter[x] = (ptrSatOrigin[x] + ptrSatDiff[x]);
		}

	}
	
}
