#pragma once


#define ORANGE			15
#define YELLOW			30
#define CHARTREUSE		45
#define GREEN			60
#define SPRING			75
#define CYAN			90
#define AZURE			105
#define BLUE			120
#define VIOLET			135
#define MAGENTA			150
#define ROSE			175
#define RED				0

#define HUE_MIN			0
#define HUE_MAX			179
#define SAT_MIN			0
#define SAT_MAX			255
#define VAL_MIN			0
#define VAL_MAX			255

#define HUE_RED_LB		166
#define HUE_RED_UB		10
#define HUE_ORANGE_LB	7 
#define HUE_ORANGE_UB	20
#define HUE_YELLOW_LB	16
#define HUE_YELLOW_UB	40
#define HUE_GREEN_LB	36
#define HUE_GREEN_UB	80
#define HUE_BLUE_LB		81
#define HUE_BLUE_UB		130
#define HUE_VIOLET_LB	131
#define HUE_VIOLET_UB	165


#define RANGE_RED(x)		(HUE_RED_LB <= x && x <= HUE_MAX) || (HUE_MIN <= x && x <= HUE_RED_UB)
#define RANGE_ORANGE(x)		(HUE_ORANGE_LB <= x && x <= HUE_ORANGE_UB)
#define RANGE_YELLOW(x)		(HUE_YELLOW_LB <= x && x <= HUE_YELLOW_UB)
#define RANGE_GREEN(x)		(HUE_GREEN_LB <= x && x <= HUE_GREEN_UB)
#define RANGE_BLUE(x)		(HUE_BLUE_LB <= x && x <= HUE_BLUE_UB)
#define RANGE_VIOLET(x)		(HUE_VIOLET_LB <= x && x <= HUE_VIOLET_UB)


#define TEST_WINDOW "Test"

#define TRACKBAR_MIN		0	
#define TRACKBAR_HUE_MID	15
#define TRACKBAR_HUE_MAX	30

#define TRACKBAR_SAT_MID	30
#define TRACKBAR_SAT_MAX	60