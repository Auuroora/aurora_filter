#include "define.h"
#include "header.h"

using namespace cv;
using namespace std;

void setBrightness(Mat &image, int val) {
	for (int y = 0; y < image.size().height; y++) {

		uchar* ptr_img = image.ptr<uchar>(y);
		for (int x = 0; x < image.size().width * 3; x++) {
			if (ptr_img[x] + val > 255)
				ptr_img[x] = 255;
			else if (ptr_img[x] + val < 0)
				ptr_img[x] = 0;
			else
				ptr_img[x] += val;
		}
	}
}

void setHot(Mat &image, int val) {
	for (int y = 0; y < image.size().height; y++) {

		uchar* ptr_img = image.ptr<uchar>(y);
		for (int x = 0; x < image.size().width; x++) {
			if (ptr_img[x * 3 + 2] + val > 255)
				ptr_img[x * 3 + 2] = 255;
			else if (ptr_img[x * 3 + 2] + val < 0)
				ptr_img[x * 3 + 2] = 0;
			else
				ptr_img[x * 3 + 2] += val;
		}
	}
}

void hueTest() {
	int r = RED, o = ORANGE, y = YELLOW, g = GREEN, b = BLUE, v = VIOLET;

	beR = beO = beY = beG = beB = beV = 0;
	afR = afO = afY = afG = afB = afV = 0;

	cvtColor(originImg, hsvImg, COLOR_BGR2HSV);
	split(hsvImg, originSplit);
	split(hsvImg, filterSplit);


	namedWindow("Original", WINDOW_NORMAL);
	resizeWindow("Original", 1000, 500);
	setMouseCallback("Original", mouseCallback, &originImg);

	namedWindow(TEST_WINDOW, WINDOW_NORMAL);
	resizeWindow(TEST_WINDOW, 1000, 900);
	setMouseCallback(TEST_WINDOW, mouseCallback, &filterSplit[0]);


	void(*fncPtr)(int pos, void* ptr) = onChangeHue;

	createTrackbar("H(RED)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &r);
	setTrackbarPos("H(RED)", TEST_WINDOW, TRACKBAR_HUE_MID);
	
	createTrackbar("H(ORANGE)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &o);
	setTrackbarPos("H(ORANGE)", TEST_WINDOW, TRACKBAR_HUE_MID);

	createTrackbar("H(YELLOW)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &y);
	setTrackbarPos("H(YELLOW)", TEST_WINDOW, TRACKBAR_HUE_MID);

	createTrackbar("H(GREEN)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &g);
	setTrackbarPos("H(GREEN)", TEST_WINDOW, TRACKBAR_HUE_MID);

	createTrackbar("H(BLUE)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &b);
	setTrackbarPos("H(BLUE)", TEST_WINDOW, TRACKBAR_HUE_MID);

	createTrackbar("H(VIOLET)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, fncPtr, &v);
	setTrackbarPos("H(VIOLET)", TEST_WINDOW, TRACKBAR_HUE_MID);

	while (waitKey(0) != 27);
}

void satTest() {
	int r = RED, o = ORANGE, y = YELLOW, g = GREEN, b = BLUE, v = VIOLET;

	beR = beO = beY = beG = beB = beV = 0;
	afR = afO = afY = afG = afB = afV = 0;

	cvtColor(originImg, hsvImg, COLOR_BGR2HSV);
	split(hsvImg, originSplit);
	split(hsvImg, filterSplit);

	namedWindow("Original", WINDOW_NORMAL);
	resizeWindow("Original", 1000, 500);
	setMouseCallback("Original", mouseCallback, &originImg);

	namedWindow(TEST_WINDOW, WINDOW_NORMAL);
	resizeWindow(TEST_WINDOW, 1000, 900);
	setMouseCallback(TEST_WINDOW, mouseCallback, &filterSplit[1]);


	void(*fncPtr)(int pos, void* ptr) = onChangeSaturation;

	createTrackbar("S(RED)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &r);
	setTrackbarPos("S(RED)", TEST_WINDOW, TRACKBAR_SAT_MID);

	createTrackbar("S(ORANGE)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &o);
	setTrackbarPos("S(ORANGE)", TEST_WINDOW, TRACKBAR_SAT_MID);

	createTrackbar("S(YELLOW)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &y);
	setTrackbarPos("S(YELLOW)", TEST_WINDOW, TRACKBAR_SAT_MID);

	createTrackbar("S(GREEN)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &g);
	setTrackbarPos("S(GREEN)", TEST_WINDOW, TRACKBAR_SAT_MID);

	createTrackbar("S(BLUE)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &b);
	setTrackbarPos("S(BLUE)", TEST_WINDOW, TRACKBAR_SAT_MID);

	createTrackbar("S(VIOLET)", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_SAT_MAX, fncPtr, &v);
	setTrackbarPos("S(VIOLET)", TEST_WINDOW, TRACKBAR_SAT_MID);

	while (waitKey(0) != 27);
}