#pragma once

#include <opencv2/opencv.hpp>
#include <map>
#include <iostream>

using namespace cv;
using namespace std;

typedef struct IMG {
	Mat* originImage;
	Mat* mask;
	int color;
														
	IMG(Mat* img, Mat* m, int c) : originImage(img), mask(m), color(c) {};
} IMG;

// HSV.cpp
void regHue(int color, int val);
void regSat(int color, int val);

// testFunc.cpp
void setBrightness(Mat &image, int val);
void setHot(Mat &image, int val);
void hueTest();
void satTest();


// window.cpp
void onChangeHue(int pos, void* ptr);
void onChangeSaturation(int v, void* ptr);
void onChangeValue(int v, void* ptr);
void mouseCallback(int event, int x, int y, int flags, void *userdata);

// Variable
extern Mat originImg, hsvImg;
extern Mat originSplit[3];
extern Mat filterSplit[3];
extern Mat hueDiff, satDiff, valDiff;

extern int beR, beO, beY, beG, beB, beV;
extern int afR, afO, afY, afG, afB, afV;