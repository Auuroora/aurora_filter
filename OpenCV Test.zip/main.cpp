﻿#include "define.h"
#include "header.h"

using namespace cv;
using namespace std;

Mat originImg, hsvImg, resImg;
Mat originSplit[3];
Mat filterSplit[3];
Mat hueDiff, satDiff, valDiff;

int beR, beO, beY, beG, beB, beV;
int afR, afO, afY, afG, afB, afV;

int flag;

void onChange(int pos, void* ptr) {
	flag = 1;
}

int main() {
	originImg = imread("test5.PNG", IMREAD_COLOR);
	if (originImg.empty()){
		cout << "Image Open Failed" << endl;
		return -1;
	}
	
	hueDiff = Mat::zeros(originImg.rows, originImg.cols, CV_16S);
	satDiff = Mat::zeros(originImg.rows, originImg.cols, CV_16S);
	valDiff = Mat::zeros(originImg.rows, originImg.cols, CV_16S);

	hueTest();
	//satTest();

	/*
	cv::cvtColor(originImg, hsvImg, COLOR_BGR2HSV);
	split(hsvImg, originSplit);
	split(hsvImg, filterSplit);

	namedWindow("Original", WINDOW_NORMAL);
	resizeWindow("Original", 1000, 500);
	//setMouseCallback("Original", mouseCallback, &originImg);

	namedWindow(TEST_WINDOW, WINDOW_NORMAL);
	resizeWindow(TEST_WINDOW, 1000, 500);
	//setMouseCallback(TEST_WINDOW, mouseCallback, &filterSplit[0]);

	createTrackbar("H", TEST_WINDOW, TRACKBAR_MIN, TRACKBAR_HUE_MAX, onChange);
	setTrackbarPos("H", TEST_WINDOW, TRACKBAR_HUE_MID);

	
	int before = 0, after = 0;
	cv::imshow("Original", originImg);


	while (1) {
		int cnt = getTrackbarPos("H", TEST_WINDOW) - 10;
		swap(before, after);
		after = cnt;
		cnt = after - before;

		if (flag) {
			cout << "Changed!" << endl;
			for (int y = 0; y < originImg.size().height; y++) {

				uchar* ptrHue = originSplit[0].ptr<uchar>(y);
				ushort* ptrDiff = filter.ptr<ushort>(y);

				for (int x = 0; x < originImg.size().width; x++) {
					if (HUE_YELLOW_LB <= ptrHue[x] && ptrHue[x] <= HUE_YELLOW_UB) {
						ptrDiff[x] += cnt;
					}
				}

			}


			for (int y = 0; y < originImg.size().height; y++) {

				uchar* ptrHue = originSplit[0].ptr<uchar>(y);
				uchar* ptrFilter = filterSplit[0].ptr<uchar>(y);
				ushort* ptrDiff = filter.ptr<ushort>(y);

				for (int x = 0; x < originImg.size().width; x++) {
					if (ptrHue[x] + ptrDiff[x] < 0)
						ptrFilter[x] = (ptrHue[x] + ptrDiff[x] + 180);
					else
						ptrFilter[x] = (ptrHue[x] + ptrDiff[x]) % 180;
				}

			}

			cv::merge(filterSplit, 3, hsvImg);
			cv::cvtColor(hsvImg, resImg, COLOR_HSV2BGR);
			cv::imshow(TEST_WINDOW, resImg);
			flag = 0;
		}
		
		if (waitKey(1) == 27) break;
	}
	*/

	destroyAllWindows();
	return 0;
}