#include "define.h"
#include "header.h"

using namespace cv;
using namespace std;

void mouseCallback(int event, int x, int y, int flags, void *userdata) {
	Mat img = *((Mat*)userdata);
	Mat HSVImage;
	if (img.channels() == 1) {
		cout << "H:" << (double)img.at<uchar>(y, x) << endl;
	}
	else {
		cvtColor(img, HSVImage, COLOR_BGR2HSV);
		cout << "H:" << (int)HSVImage.at<Vec3b>(y, x)[0];
		cout << ", S:" << (int)HSVImage.at<Vec3b>(y, x)[1];
		cout << ", V:" << (int)HSVImage.at<Vec3b>(y, x)[2] << endl;
	}
}

void onChangeHue(int pos, void* ptr) {
	Mat resImg;
	int color = *((int*)ptr);

	regHue(color, (pos - TRACKBAR_HUE_MID));
	
	merge(filterSplit, 3, hsvImg);
	cvtColor(hsvImg, resImg, COLOR_HSV2BGR);
	imshow(TEST_WINDOW, resImg);
	imshow("Original", originImg);
}

void onChangeSaturation(int pos, void* ptr) {
	Mat resImg;
	int color = *((int*)ptr);

	regSat(color, (pos - TRACKBAR_SAT_MID));

	merge(filterSplit, 3, hsvImg);
	cvtColor(hsvImg, resImg, COLOR_HSV2BGR);
	imshow(TEST_WINDOW, resImg);
	imshow("Original", originImg);
}

void onChangeValue(int v, void* ptr) {
	Mat img = ((Mat*)ptr)->clone();

	// TO DO

}